function z = funct(t, y)
z = ( 1 - y)   