%x_d is velocity
function z = PartE_funct(t, x, x_d)
z = 25 * ( 6 * ( 1 - x ) - x_d)   